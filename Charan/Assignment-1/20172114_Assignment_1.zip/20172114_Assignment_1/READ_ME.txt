===================Assignment-1===================

Step-1 : Run Make
		 >> make

Step-2 : Run Alice and Bob Programs in seperately

		./Alice <command-1> <command-2>  
		./Bob <command-1> <command-2>
		
		Note:
			command-1: 0/1
			 		   0 -> Server
			 		   1 -> Client
			command-2: XXXX (4-Digit Integer)
					   XXXX -> Port number to bind for Server if it is Server 
					   XXXX -> Port number of server to connect if it is Client

		Example:
			>> ./Alice 0 5000
			>> ./Bob 1 5000

			PS: Here Alice hosts the server with port number 5000 and Bob connects to the port number 5000
				(i)  Alice acts as SERVER
				(ii) Bob   acts as CLIENT


Step-3 :  (i) Use keyword Sending <filename> <TCP/UDP>
		  (ii) You can any Messages and any kind of files.

Please refer to Screenshot attached for more info

======================================================================================

Please contact me in case of any issue:

	Name: Sai Charan Regunta
	Programme: MS by Research (CSTAR)
	Phone: 9490102123
	Email: sai.regunta@research.iiit.ac.in